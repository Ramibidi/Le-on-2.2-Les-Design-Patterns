         
        <h1>Mon premier site PHP</h1>
            <div style="background-color : #E6E6FA ;clear:both; height: 20px">
            <ul style="display:flex; justify-content : space-evenly;">
                <li style="color: black"><strong>Home</strong></li>
            
                
                
               
            </ul>
        </div>
            
  