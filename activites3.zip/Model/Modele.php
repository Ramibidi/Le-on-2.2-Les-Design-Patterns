<?php
require('connectDB.php');


class Article
{


    public function getArticles()
    {
        $connexion = new connectDB();
        $connex = $connexion->getConnection();
        $get = 'SELECT * from posts';
        $soome = mysqli_query($connex, $get);
        $articles = mysqli_fetch_all($soome, MYSQLI_ASSOC);
        return $articles;
    }



    
    public function postArticle()
    {
        
        $connexion = new connectDB();
        $connex = $connexion->getConnection();

        if (isset($_POST['submit'])) {

            $post = isset($_POST['post']) ? $_POST['post'] : '';
            $insr = "INSERT INTO posts(post) VALUES ('$post')";
            if (mysqli_query($connex, $insr)) {
                echo "  ajouter !!! ";
            } else {
                echo '!!!!!!! ' . mysqli_error($conn);
            }
        }
    }


  
}
