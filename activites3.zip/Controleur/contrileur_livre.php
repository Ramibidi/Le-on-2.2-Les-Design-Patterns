<?php

require('Model/model_livre.php');

function query_Liv()

{
    $livre = new Livre();
    $livre2 = $livre->getMessages();
    require('View/livre.php');
}

function iner_Liv()

{
    $livre = new Livre();
    $livre2 = $livre->postMessage();
    return $livre2;
}
