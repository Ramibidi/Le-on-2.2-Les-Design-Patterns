<?php

require('Controleur/controleur.php');


    query_Posts();
    insr_Post();
