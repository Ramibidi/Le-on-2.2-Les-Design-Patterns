<?php  require_once 'Modele/model.php' ;  ?>
<h1>Mon premier site PHP</h1>
            <div style="background-color : #E6E6FA ;clear:both;height: 20px">
            <ul style="display:flex; justify-content : space-evenly;">
                <li><a href="index.php" style="color: black"><strong>Home</strong></a></li>
                
                
				
               
            </ul>
        </div>
       
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="style.css"/>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<center>
<form method="post" action="index.php">
	<fieldset>
	<legend style="color: black"> <strong>les posts</strong></legend>
	<p>
		<label for="nom">Post:</label>
		<input type="text" name="post"  autofocus required/>
    </p>
	
    <input type="submit" name="btn_ajouter" value="Ajouter" />
	
	
  
</fieldset>
</form>
</center>


<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>




<?php
include ('footer.php');
?>
</body>
</html>
