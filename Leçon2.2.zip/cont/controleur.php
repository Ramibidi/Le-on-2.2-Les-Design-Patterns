
<?php 
/*
require_once 'index.php' ;
$bd = new Articles('blog') ;
$datas =$bd->query() ;
        $bd->insr() ;
        var_dump($datas);
*/
require_once 'Modele/model.php' ;

function query() 
{
       $article = new Articles('blog') ;
       $datas =$article->query() ;
       require_once 'Vuew/vue.php' ;
       var_dump($datas);
}

function insr()
{
       $article = new Articles('blog') ;
       $article->insr() ; 
       return $article ;
       
}
?>