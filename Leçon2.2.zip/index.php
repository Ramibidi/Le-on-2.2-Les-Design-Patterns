
<?php 
/*
        require_once 'Vuew/vue.php' ;
        require_once 'Modele/model.php' ;
        $bd = new Articles('blog') ;
        $datas =$bd->query() ;
        $bd->insr() ;
        var_dump($datas);
        
  */      
    
  require_once 'Cont/controleur.php' ;
        
  query() ;
  insr() ;



/*


require ('leila.php');

$article = new Article();

$response = $article->getPosts();



require ('vue.php');

$article->addPost();

*/


?>