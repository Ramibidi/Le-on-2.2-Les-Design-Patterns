<?php
class Articles{

  private $db_name ;
  private $db_usre ;
  private $db_pass ;
  private $db_host ;
  private $bdd ;

public function __construct($db_name , $db_usre='root',$db_pass='',$db_host='localhost' )
{
  $this->db_name = $db_name ;
  $this->db_usre = $db_usre ;
  $this->db_pass = $db_pass ;
  $this->db_host = $db_host ;

}


private function getPDO()
{
  $bdd = new PDO('mysql:host=localhost;dbname=blog;charset=utf8', 'root', '');
  
  $this->bdd = $bdd ;
  return $bdd ;
}

public function query()
{
  $req = $this->getPDO()->query("SELECT * FROM posts");
  $datas = $req->fetchALL(PDO::FETCH_OBJ) ;
  return $datas ;
}
 
public function insr()
{
    /*
    if(isset($_POST['btn_ajouter']))
            {
                $post=$_POST['post']; echo $post; 
                $req2 = $this->getPDO()->prepare("INSERT INTO posts(post) VALUES(?)") ;
                echo "<script>
                alert('Post publié avec succès!');
                window.location.href = 'http:index.php';
               </script>";
               return $req2 ;

               */

              if( isset($_POST) AND !empty($_POST) )
              {
                  $post=$_POST['post']; echo $post; 
                  
                  

                  $this->getPDO()->exec('INSERT INTO posts(post ) VALUES("'.$_POST['post'] .'")');
                  
                  echo "<script>
                       alert('Post publié avec succès!');
                       window.location.href = 'http:index.php';
                      </script>";
                     
                  
              }
            }
}


  



  ?>









