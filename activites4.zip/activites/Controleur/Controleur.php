<?php

require('Model/Modele.php');

function  query_Posts()

{
    $article = new Article();
    $articles = $article->getArticles();
    var_dump($articles);
    require('View/Vue.php');
}



function insr_Post()

{
    $article = new Article();
    $articles = $article->postArticle();
    return $articles;
}
