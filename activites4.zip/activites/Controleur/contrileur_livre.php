<?php

require('Model/modele_livre.php');

function query_Liv()

{
    $livre = new Livre();
    $livre2 = $livre->getArticles();
    var_dump($livre2);
    require('View/livre.php');
}

function iner_Liv()

{
    $livre = new Livre();
    $livre2 = $livre->postArticle();
    return $livre2;
}
