<?php
require('connectDB.php');


class Livre
{


    public function getArticles()
    {
        $connexion = new connectDB();
        $connex = $connexion->getConnection();
        $get = 'SELECT * from livre';
        $soome = mysqli_query($connex, $get);
        $articles = mysqli_fetch_all($soome, MYSQLI_ASSOC);
        return $articles;
    }



    
    public function postArticle()
    {
        
        $connexion = new connectDB();
        $connex = $connexion->getConnection();

        if (isset($_POST['submit'])) {

            $post = isset($_POST['post']) ? $_POST['post'] : '';
            $insr = "INSERT INTO livre(post) VALUES ('$post')";
            if (mysqli_query($connex, $insr)) {
                echo "  ajouter !!! ";
            } else {
                echo '!!!!!!! ' . mysqli_error($connex);
            }
        }
    }


  
}
