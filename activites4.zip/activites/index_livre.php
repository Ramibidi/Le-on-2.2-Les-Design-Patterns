<?php

require ('Controleur/contrileur_livre.php');

query_Liv() ;
iner_Liv() ;

